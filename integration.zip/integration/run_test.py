from voice_transcriber import transcribe_from_microphone

result = transcribe_from_microphone()
print(result)
